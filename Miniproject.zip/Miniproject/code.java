import java.util.*;

// Edge class representing a road between two locations
class Edge {
    int dest, weight;
    
    Edge(int dest, int weight) {
        this.dest = dest;
        this.weight = weight;
    }
}

// Graph class representing the city, using an adjacency list
class Graph {
    int V;  // Number of locations
    List<List<Edge>> adjList;
    
    Graph(int V) {
        this.V = V;
        adjList = new ArrayList<>(V);
        for (int i = 0; i < V; i++) {
            adjList.add(new ArrayList<>());
        }
    }
    
    // Add a road (bidirectional edge) between two locations
    void addEdge(int src, int dest, int weight) {
        adjList.get(src).add(new Edge(dest, weight));
        adjList.get(dest).add(new Edge(src, weight)); // Bidirectional road
    }
    
    // Method to update traffic conditions (change road weight)
    void updateTraffic(int src, int dest, int newWeight) {
        for (Edge edge : adjList.get(src)) {
            if (edge.dest == dest) {
                edge.weight = newWeight;
                break;
            }
        }
        for (Edge edge : adjList.get(dest)) {
            if (edge.dest == src) {
                edge.weight = newWeight;
                break;
            }
        }
    }
    
    // Dijkstra's algorithm to find the shortest path from a source location
    int[] dijkstra(int src) {
        int[] dist = new int[V];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[src] = 0;

        PriorityQueue<int[]> minHeap = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        minHeap.add(new int[]{src, 0});

        while (!minHeap.isEmpty()) {
            int[] node = minHeap.poll();
            int u = node[0], d = node[1];

            if (d > dist[u]) continue;

            for (Edge edge : adjList.get(u)) {
                int v = edge.dest, weight = edge.weight;

                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    minHeap.add(new int[]{v, dist[v]});
                }
            }
        }
        return dist;
    }
}

// User class representing a passenger or driver
class User {
    String name;
    int location;

    User(String name, int location) {
        this.name = name;
        this.location = location;
    }

    void updateLocation(int newLocation) {
        this.location = newLocation;
    }
}

// RideRequest class representing a ride request
class RideRequest {
    User passenger;
    User driver;
    int distanceToDriver;

    RideRequest(User passenger, User driver, int distanceToDriver) {
        this.passenger = passenger;
        this.driver = driver;
        this.distanceToDriver = distanceToDriver;
    }

    // Match the passenger to the closest available driver
    static RideRequest createRequest(User passenger, List<User> drivers, Graph city) {
        int[] distances = city.dijkstra(passenger.location);
        User closestDriver = null;
        int minDistance = Integer.MAX_VALUE;

        for (User driver : drivers) {
            int distance = distances[driver.location];
            if (distance < minDistance) {
                minDistance = distance;
                closestDriver = driver;
            }
        }
        
        return new RideRequest(passenger, closestDriver, minDistance);
    }
}

public class RideSharingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Create the city graph with 6 locations
        int locations = 6;
        Graph city = new Graph(locations);

        // Add roads (edges) between locations
        city.addEdge(0, 1, 4);
        city.addEdge(0, 2, 2);
        city.addEdge(1, 2, 1);
        city.addEdge(1, 3, 5);
        city.addEdge(2, 3, 8);
        city.addEdge(2, 4, 10);
        city.addEdge(3, 4, 2);
        city.addEdge(3, 5, 6);
        city.addEdge(4, 5, 3);

        // Update traffic (example: road between 2 and 4 becomes slower)
        city.updateTraffic(2, 4, 5);
        
        // Create some users (drivers and passengers)
        List<User> drivers = new ArrayList<>();
        drivers.add(new User("Driver1", 0));
        drivers.add(new User("Driver2", 3));
        drivers.add(new User("Driver3", 5));
        
        List<User> passengers = new ArrayList<>();
        passengers.add(new User("Passenger1", 1));
        passengers.add(new User("Passenger2", 4));
        
        // Ride request simulation
        System.out.println("Welcome to the Ride-Sharing System!");
        
        while (true) {
            System.out.println("\n1. Request a Ride");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            
            if (choice == 1) {
                // Passenger's location
                System.out.print("Enter your name: ");
                String passengerName = scanner.next();
                System.out.print("Enter your location (0 to 5): ");
                int passengerLocation = scanner.nextInt();

                // Create a passenger user
                User passenger = new User(passengerName, passengerLocation);

                // Create a ride request and find the closest driver
                RideRequest rideRequest = RideRequest.createRequest(passenger, drivers, city);
                
                if (rideRequest != null) {
                    System.out.println("Ride matched! Driver: " + rideRequest.driver.name + ", Distance: " + rideRequest.distanceToDriver);
                } else {
                    System.out.println("No available driver found.");
                }
            } else if (choice == 2) {
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }
}
